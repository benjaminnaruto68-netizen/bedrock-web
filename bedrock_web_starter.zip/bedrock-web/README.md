# Bedrock Web

A free, original browser-based voxel sandbox starter project.

## Run locally
Open `index.html` in a modern browser while connected to the internet. The Three.js library is loaded from jsDelivr.

## Publish free with GitHub Pages
1. Sign in to GitHub and create a new **public** repository named `bedrock-web`.
2. Choose **Add file → Upload files**.
3. Upload `index.html` from this folder and commit the change.
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose branch `main`, folder `/ (root)`, then Save.
7. Wait for GitHub to publish. Your site address will look like `https://YOUR-USERNAME.github.io/bedrock-web/`.

## Controls
- Desktop: WASD move, mouse look, Space jump, left click break, right click place, keys 1–6 select blocks.
- Mobile: left joystick moves, drag the right side to look, buttons break/place/jump.
- Creative mode: fly up with Space and down with Shift.
- Save stores the current world in this browser's local storage on this device.

## Current limitations
This is a starter prototype, not Minecraft or the official Bedrock engine. It has a small generated world, basic block interaction, simple survival/creative controls, and local browser saves. Multiplayer, mobs, crafting, chunk streaming, robust collision, and cross-device cloud saves are not implemented yet. GitHub Pages hosts static files; real multiplayer later will need a separate server. The game requires internet access to load Three.js from the CDN.
